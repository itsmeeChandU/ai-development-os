# Prompt To Product Packet

```json
{
  "development_strategy_plan": {
    "blockers": [
      {
        "evidence": "manifests/development_strategy_router.json",
        "gate": "closed",
        "id": "strategy:m5_cross_border_supply_chain:external-inputs",
        "issue": "development mode needs external inputs before final readiness",
        "module": "development_strategy_router",
        "next_valid_move": "Collect or block: customs/tariff evidence, country regulations, licensed broker or compliance expert when needed",
        "owner": "architect",
        "unsafe_to_bypass": true
      }
    ],
    "country": "Canada",
    "country_requirements_template": {
      "proof_boundary": "Country and import/export requirements must come from current official sources or qualified logistics/compliance experts before action.",
      "required_fields": [
        "country",
        "product_category",
        "import_rules_source",
        "export_rules_source",
        "tariff_or_hs_code_status",
        "certification_requirements",
        "restricted_party_or_sanctions_check",
        "logistics_constraints",
        "local_partner_or_broker_needed",
        "next_valid_move"
      ]
    },
    "external_contract_template": {
      "proof_boundary": "AI can draft a checklist; signed contracts and qualified review are external gates.",
      "required_fields": [
        "contract_type",
        "counterparty",
        "scope",
        "rights_granted",
        "data_or_ip_terms",
        "liability_boundary",
        "termination",
        "review_owner",
        "launch_gate"
      ]
    },
    "field": "import_export",
    "field_playbooks": [
      {
        "default_mode": "M5_CROSS_BORDER_SUPPLY_CHAIN",
        "field": "import_export",
        "first_agents": [
          "research",
          "procurement",
          "compliance",
          "operations"
        ],
        "first_artifacts": [
          "country requirements matrix",
          "tariff/customs evidence",
          "logistics blockers"
        ]
      }
    ],
    "generated_at": "2026-06-26T01:25:12+00:00",
    "idea": "Canada-focused importer source readiness copilot with startup lifecycle R&D, operator screenshot evidence, and board go-live gates",
    "kind": "development_strategy_plan",
    "modes": [
      {
        "agent_mix": [
          "research",
          "procurement",
          "compliance",
          "operations",
          "qualified expert"
        ],
        "external_inputs": [
          "customs/tariff evidence",
          "country regulations",
          "licensed broker or compliance expert when needed"
        ],
        "id": "M5_CROSS_BORDER_SUPPLY_CHAIN",
        "proof_gates": [
          "country requirements matrix",
          "import/export blocker",
          "supplier/legal review",
          "logistics plan"
        ],
        "use_when": "Import/export, country-specific sourcing, tariffs, customs, certifications, logistics, or regional compliance."
      }
    ],
    "next_valid_move": "Assign agents by mode, collect external inputs, and keep final claims blocked until evidence exists.",
    "status": "ready_with_external_gates"
  },
  "execution_plan": {
    "agent_supervision": {
      "coordinator_rules": [
        "Spawn workers only after owned files and proof commands are defined.",
        "Use Ruflo for worker records and hook routing, not repo truth.",
        "Reject handoffs that lack proof results or next_valid_move rows.",
        "Merge verified branches only after branch freshness checks.",
        "Record final branch, commit, commands, generated artifacts, blockers, and unsafe gates."
      ],
      "status_schema": {
        "blocked_requires": [
          "owner",
          "evidence",
          "next_valid_move"
        ],
        "values": [
          "pending",
          "active",
          "blocked",
          "verified",
          "merged"
        ],
        "verified_requires": [
          "commit",
          "commands_run",
          "proof_results"
        ]
      }
    },
    "automation_runtime": {
      "commands": {
        "automation-check": "Validate runtime packet builders without external side effects.",
        "ci-fix": "Emit a CI failure repair handoff without weakening proof gates.",
        "command-spec": "Render one slash command packet with required inputs and proof gates.",
        "emit-slash-commands": "Materialize slash command specs for agents and LLMs.",
        "harness-intake": "Emit an external agent harness integration packet with adoption gates and proof boundaries.",
        "lane-packet": "Emit one bounded worker packet with owned files and proof commands.",
        "prompt-to-product": "Normalize an idea and emit a product packet with lane plan.",
        "repo-intake": "Select internal/helper repos and product-target repo boundaries for an idea.",
        "research-plan": "Route subject expertise, web research, official sources, datasets, and expert validation.",
        "routine-report": "Emit safe background routine commands and input blockers.",
        "scheduler-plan": "Emit a scheduler-ready plan for routine invocation.",
        "strategy-plan": "Choose field-specific development mode, agents, external inputs, contracts, and proof gates."
      },
      "effectful_execution_rule": "Commands default to dry-run or packet generation. Network, push, live, paid, legal, or external effects require explicit operator intent, clean repo proof, and passing gates.",
      "generated_artifacts": [
        "system_review_graph/prompt_to_product_packet.json",
        "system_review_graph/internal_repo_intake_packet.json",
        "system_review_graph/research_data_plan.json",
        "system_review_graph/development_strategy_plan.json",
        "system_review_graph/external_harness_integration_packet.json",
        "system_review_graph/slash_command_specs.json",
        "system_review_graph/automation_runtime_report.json",
        "system_review_graph/scheduler_plan.json",
        "product_projects/<product>/docs/STARTUP_LIFECYCLE.md",
        "product_projects/<product>/system_review_graph/board_go_live_readiness_report.json",
        "product_projects/<product>/system_review_graph/operator_workflow_report.json",
        "product_projects/<product>/system_review_graph/operator_screenshot_manifest.json",
        "product_projects/<product>/system_review_graph/operator_screenshots/*",
        "product_projects/<product>/board/board_go_live_brief.md",
        "handoffs/ci_fix_<check>.json"
      ],
      "runner": "scripts/agentic_workflow_orchestrator.py",
      "safe_default": "dry_run"
    },
    "background_routines": [
      {
        "allowed_effects": [
          "git fetch",
          "git status",
          "git merge-base checks"
        ],
        "cadence": "before every lane and merge",
        "id": "branch_freshness_check",
        "prohibited_effects": [
          "destructive reset",
          "force push without explicit instruction"
        ],
        "proof_output": "branch freshness row in handoff",
        "trigger": "lane_start or merge_start"
      },
      {
        "allowed_effects": [
          "load SRG bundle",
          "emit bounded context JSON"
        ],
        "cadence": "before lane assignment and after contract changes",
        "id": "context_bundle_refresh",
        "prohibited_effects": [
          "copy private data into generated docs"
        ],
        "proof_output": "repo_context_bundle path or missing-context blocker",
        "trigger": "srg_manifest or code_review_graph_contract changes"
      },
      {
        "allowed_effects": [
          "read blocker ledgers",
          "mark stale blockers with next_valid_move"
        ],
        "cadence": "daily or before final handoff",
        "id": "stale_blocker_sweep",
        "prohibited_effects": [
          "close blocker without evidence"
        ],
        "proof_output": "current blocker table",
        "trigger": "goal checkpoint"
      },
      {
        "allowed_effects": [
          "read generated reports",
          "write continuation plan",
          "write blocker rows"
        ],
        "cadence": "before completion claims for product/startup work",
        "id": "startup_continuation_sweep",
        "prohibited_effects": [
          "claim fully operational or launch ready while must_continue is true"
        ],
        "proof_output": "system_review_graph/continuation_plan.json",
        "trigger": "readiness or external-gate status is ready_with_external_gates"
      },
      {
        "allowed_effects": [
          "read generated reports",
          "write investor packet",
          "write VC pitch readiness report"
        ],
        "cadence": "before investor pitch claims",
        "id": "vc_pitch_readiness_sweep",
        "prohibited_effects": [
          "claim revenue, PMF, legal, financing, compliance, buyer, supplier, customs, tariff, public launch, or full operational proof without evidence"
        ],
        "proof_output": "system_review_graph/vc_pitch_readiness_report.json",
        "trigger": "product needs VC pitch readiness"
      },
      {
        "allowed_effects": [
          "read generated reports",
          "write board packet",
          "write board go-live readiness report"
        ],
        "cadence": "before go-live, board, private beta, or launch-readiness claims",
        "id": "board_go_live_readiness_sweep",
        "prohibited_effects": [
          "claim public launch, production deployment, legal, financial, compliance, buyer, revenue, PMF, supplier, customs, tariff, or regulated proof without qualified human approval"
        ],
        "proof_output": "system_review_graph/board_go_live_readiness_report.json",
        "trigger": "product needs board go-live readiness"
      },
      {
        "allowed_effects": [
          "read harness docs",
          "write harness integration packet",
          "run local validators",
          "run local config/security scan when installed"
        ],
        "cadence": "before installing, copying, or relying on an optional external agent harness",
        "id": "external_harness_safety_check",
        "prohibited_effects": [
          "global install without explicit operator approval",
          "duplicate hook/plugin install",
          "network write",
          "paid API use",
          "credential mutation",
          "weakened proof gates"
        ],
        "proof_output": "system_review_graph/external_harness_integration_packet.json",
        "trigger": "external harness requested or harness packet generated"
      },
      {
        "allowed_effects": [
          "run idempotent tests",
          "run validators",
          "write eval report"
        ],
        "cadence": "overnight when requested and safe",
        "id": "nightly_eval_loop",
        "prohibited_effects": [
          "live external execution",
          "paid API usage without budget gate"
        ],
        "proof_output": "eval report with command results",
        "trigger": "long-running goal with bounded proof commands"
      },
      {
        "allowed_effects": [
          "read CI logs",
          "classify failure",
          "write fix lane packet"
        ],
        "cadence": "on CI failure",
        "id": "ci_failure_triage",
        "prohibited_effects": [
          "hide failing checks",
          "weaken tests without a task contract"
        ],
        "proof_output": "CI blocker or verified fix branch",
        "trigger": "GitHub check failure"
      }
    ],
    "canonical_truth": {
      "boundary": "Ruflo records coordination only. Repo files, generated artifacts, tests, and GitHub history remain canonical.",
      "coordination_memory": "Ruflo",
      "version_control": "GitHub"
    },
    "ci_cd_agent_jobs": [
      {
        "commands": [
          "python scripts/ai_dev_os_check.py",
          "python scripts/workflow_manifest_check.py",
          "python scripts/agentic_workflow_orchestrator.py validate",
          "python scripts/agentic_workflow_orchestrator.py automation-check",
          "python scripts/eval_suite.py --manifest manifests/agentic_execution_manifest.json --out system_review_graph/eval_report.ci.json",
          "python scripts/blocker_ledger.py validate --input system_review_graph/blockers.jsonl --allow-missing --out system_review_graph/blocker_ledger_report.ci.json",
          "python scripts/self_test_flow.py"
        ],
        "gates": [
          "manifest_valid",
          "execution_manifest_valid",
          "automation_runtime_valid",
          "eval_suite_passed",
          "blocker_ledger_valid",
          "self_test_passed"
        ],
        "id": "workflow_manifest_ci",
        "repo_id": "ai-development-os",
        "trigger": "push and pull_request"
      },
      {
        "commands": [
          "python -m pytest tests/test_documentation_graph.py -q",
          "ruff check src/system_review_graph/repo_context_bundle.py src/system_review_graph/cli.py src/system_review_graph/mcp_server.py tests/test_documentation_graph.py"
        ],
        "gates": [
          "cli_context_bundle_passed",
          "mcp_context_bundle_passed"
        ],
        "id": "srg_context_bundle_ci",
        "repo_id": "system-review-graph",
        "trigger": "push and pull_request"
      },
      {
        "commands": [
          "uv run pytest tests/test_visualization.py -q",
          "uv run ruff check code_review_graph tests"
        ],
        "gates": [
          "contract_sections_present",
          "lint_passed"
        ],
        "id": "code_review_contract_ci",
        "repo_id": "code-review-graph",
        "trigger": "push and pull_request"
      },
      {
        "commands": [
          "python -m pytest tests/test_code_review_graph.py -q",
          "python -m ruff check scripts/code_review_graph.py tests/test_code_review_graph.py"
        ],
        "gates": [
          "contract_export_passed",
          "product_logic_untouched"
        ],
        "id": "ih_contract_export_ci",
        "repo_id": "intelligence-hub",
        "trigger": "manual or repo CI"
      }
    ],
    "coordinator_checks": [
      "fetch every repo before merge",
      "run lane proof commands before push",
      "refresh generated artifacts from the final tree",
      "write blocker rows for missing context or failing checks",
      "push main only when explicitly requested and checks pass"
    ],
    "eval_loops": [
      {
        "failure_output": "blocker row with lane id and missing field",
        "id": "lane_packet_completeness",
        "measurement": "scripts/agentic_workflow_orchestrator.py validate",
        "pass_condition": "No missing lane packet fields.",
        "predicate": "Every lane has goal, repo_id, mode, allowed_files, forbidden_files, proof_commands, and handoff_template."
      },
      {
        "failure_output": "contract blocker with next_valid_move to update exporter",
        "id": "contract_section_coverage",
        "measurement": "scripts/workflow_manifest_check.py",
        "pass_condition": "All required sections are present in the workflow contract.",
        "predicate": "The code-review graph contract covers files, modules, symbols, imports, edges, tests, generated artifacts, and risk/ownership hints."
      },
      {
        "failure_output": "stale branch blocker",
        "id": "branch_freshness",
        "measurement": "git fetch origin && git merge-base --is-ancestor origin/main HEAD",
        "pass_condition": "Branch contains origin/main or is rebased before merge.",
        "predicate": "Lane branches are based on current origin/main before merge."
      },
      {
        "failure_output": "handoff blocker",
        "id": "handoff_completeness",
        "measurement": "handoff schema review",
        "pass_condition": "Required fields are complete and evidence-backed.",
        "predicate": "Every worker handoff names changed files, commands, results, generated artifacts, blockers, unsafe gates, and next_valid_move."
      },
      {
        "failure_output": "continuation blocker with next_valid_move to generate or repair continuation_plan.json",
        "id": "ready_with_external_gates_continuation",
        "measurement": "scripts/product_project_check.py",
        "pass_condition": "Continuation plan exists and proves the next evidence lanes before final product claims.",
        "predicate": "Any product reporting ready_with_external_gates has system_review_graph/continuation_plan.json with status startup_in_progress, must_continue true, continuation lanes, and premature completion claims closed."
      },
      {
        "failure_output": "VC pitch blocker with next_valid_move to generate or repair investor packet",
        "id": "vc_pitch_readiness",
        "measurement": "scripts/product_project_check.py",
        "pass_condition": "VC pitch packet is ready for private investor conversations without claiming launch, revenue, PMF, compliance, buyer, supplier, customs, tariff, or financing proof.",
        "predicate": "A product marked pitch-ready has vc_pitch_readiness_report.json, investor artifacts, sourced claim boundaries, diligence lanes, and premature launch/revenue/PMF/compliance claims closed."
      },
      {
        "failure_output": "Board go-live blocker with next_valid_move to generate or repair board packet",
        "id": "board_go_live_readiness",
        "measurement": "scripts/product_project_check.py",
        "pass_condition": "Board packet is ready for controlled private beta decisioning without claiming public launch, production deployment, legal, financial, compliance, buyer, revenue, PMF, supplier, customs, or tariff proof.",
        "predicate": "A product marked board-go-live candidate has board_go_live_readiness_report.json, board artifacts, an operator_workflow_report.json queue, jurisdiction tools, expert simulations, launch controls, human approval gates, and premature public launch/legal/financial/compliance claims closed."
      },
      {
        "failure_output": "external harness blocker with next_valid_move to write or repair external_harness_integration_packet.json",
        "id": "external_harness_boundary",
        "measurement": "scripts/agentic_workflow_orchestrator.py harness-intake --harness ecc --install-mode observe --target-repo ai-development-os --out-dir system_review_graph",
        "pass_condition": "Harness packet is generated without opening install, network-write, paid, credential, push, deploy, legal, or launch gates.",
        "predicate": "Optional external harness packets record source, license, inspected ref, install mode, blocked effects, command mapping, security gates, and blocked launch/commercial claims."
      },
      {
        "failure_output": "main integration blocker",
        "id": "main_push_readiness",
        "measurement": "post-merge checks and git status",
        "pass_condition": "Target main branch is clean after passing checks and push.",
        "predicate": "Main receives only verified slices requested by the user."
      }
    ],
    "execution_manifest": "manifests/agentic_execution_manifest.json",
    "generated_at": "2026-06-26T01:25:12+00:00",
    "goal": "Canada-focused importer source readiness copilot with startup lifecycle R&D, operator screenshot evidence, and board go-live gates",
    "lane_packets": [
      {
        "allowed_files": [
          "AGENTS.md",
          "README.md",
          "docs/**",
          "manifests/**",
          "scripts/**",
          "templates/**",
          ".github/**"
        ],
        "branch": "codex/workflow-coordinator-20260626-importer-source-readiness-copilot",
        "forbidden_files": [
          "LICENSE",
          "NOTICE.md",
          "CONTRIBUTOR_TERMS.md",
          "DCO.txt"
        ],
        "goal": "Own the durable workflow, execution manifest, lane packets, CI checks, and final integration proof.",
        "handoff_required_fields": [
          "lane",
          "branch_or_worktree",
          "changed_files",
          "commands_run",
          "generated_artifacts",
          "blockers",
          "unsafe_or_external_gates",
          "next_valid_move",
          "commit",
          "push_state"
        ],
        "handoff_template": "templates/HANDOFF.md",
        "id": "workflow-coordinator",
        "mode": "goal",
        "proof_commands": [
          "python3 scripts/workflow_manifest_check.py",
          "python3 scripts/agentic_workflow_orchestrator.py validate",
          "python3 scripts/agentic_workflow_orchestrator.py plan --goal \"smoke\" --repo ai-development-os",
          "python3 scripts/ai_dev_os_check.py",
          "python3 scripts/self_test_flow.py"
        ],
        "remote": "https://github.com/itsmeeChandU/ai-development-os.git",
        "repo_id": "ai-development-os",
        "repo_role": "coordinator_layer",
        "target_branch": "main",
        "worktree": "/Users/chandu/.codex/worktrees/ai-dev-os-workflow/ai-development-os-workflow-coordinator",
        "worktree_commands": [
          "git fetch origin",
          "git worktree add /Users/chandu/.codex/worktrees/ai-dev-os-workflow/ai-development-os-workflow-coordinator -b codex/workflow-coordinator-20260626-importer-source-readiness-copilot origin/main"
        ]
      },
      {
        "allowed_files": [
          "AGENTS.md",
          "README.md",
          "docs/**",
          "manifests/**",
          "scripts/**",
          "templates/**",
          "system_review_graph/external_harness_integration_packet.*"
        ],
        "branch": "codex/external-harness-adoption-20260626-importer-source-readiness-copilot",
        "forbidden_files": [
          "LICENSE",
          "NOTICE.md",
          "CONTRIBUTOR_TERMS.md",
          "DCO.txt",
          "product_projects/**/src/**"
        ],
        "goal": "Evaluate optional external agent harnesses such as ECC, map useful same-day-product patterns, and keep adoption behind proof and security gates.",
        "handoff_required_fields": [
          "lane",
          "branch_or_worktree",
          "changed_files",
          "commands_run",
          "generated_artifacts",
          "blockers",
          "unsafe_or_external_gates",
          "next_valid_move",
          "commit",
          "push_state"
        ],
        "handoff_template": "templates/EXTERNAL_HARNESS_ADOPTION.md",
        "id": "external-harness-adoption",
        "mode": "architect",
        "proof_commands": [
          "python3 scripts/agentic_workflow_orchestrator.py harness-intake --harness ecc --install-mode observe --target-repo ai-development-os --goal \"Evaluate optional same-day product harness patterns\" --out-dir system_review_graph",
          "python3 scripts/workflow_manifest_check.py",
          "python3 scripts/agentic_workflow_orchestrator.py validate",
          "python3 scripts/agentic_workflow_orchestrator.py automation-check",
          "python3 scripts/ai_dev_os_check.py",
          "python3 scripts/self_test_flow.py"
        ],
        "remote": "https://github.com/itsmeeChandU/ai-development-os.git",
        "repo_id": "ai-development-os",
        "repo_role": "coordinator_layer",
        "target_branch": "main",
        "worktree": "/Users/chandu/.codex/worktrees/ai-dev-os-workflow/ai-development-os-external-harness-adoption",
        "worktree_commands": [
          "git fetch origin",
          "git worktree add /Users/chandu/.codex/worktrees/ai-dev-os-workflow/ai-development-os-external-harness-adoption -b codex/external-harness-adoption-20260626-importer-source-readiness-copilot origin/main"
        ]
      },
      {
        "allowed_files": [
          "src/system_review_graph/repo_context_bundle.py",
          "src/system_review_graph/cli.py",
          "src/system_review_graph/mcp_server.py",
          "tests/**",
          "README.md",
          "docs/**"
        ],
        "branch": "codex/srg-context-bundle-20260626-importer-source-readiness-copilot",
        "forbidden_files": [
          "src/system_review_graph/validate.py",
          "examples/**"
        ],
        "goal": "Expose bounded SRG, documentation graph, code-review graph, and execution workflow context through CLI and MCP.",
        "handoff_required_fields": [
          "lane",
          "branch_or_worktree",
          "changed_files",
          "commands_run",
          "generated_artifacts",
          "blockers",
          "unsafe_or_external_gates",
          "next_valid_move",
          "commit",
          "push_state"
        ],
        "handoff_template": "templates/HANDOFF.md",
        "id": "srg-context-bundle",
        "mode": "surgeon",
        "proof_commands": [
          "PYTHONPATH=src python3 -m pytest tests/test_documentation_graph.py -q",
          "PYTHONPATH=src python3 -m ruff check src/system_review_graph/repo_context_bundle.py src/system_review_graph/cli.py src/system_review_graph/mcp_server.py tests/test_documentation_graph.py"
        ],
        "remote": "https://github.com/itsmeeChandU/system-review-graph.git",
        "repo_id": "system-review-graph",
        "repo_role": "system_context_layer",
        "target_branch": "main",
        "worktree": "/Users/chandu/.codex/worktrees/ai-dev-os-workflow/system-review-graph-srg-context-bundle",
        "worktree_commands": [
          "git fetch origin",
          "git worktree add /Users/chandu/.codex/worktrees/ai-dev-os-workflow/system-review-graph-srg-context-bundle -b codex/srg-context-bundle-20260626-importer-source-readiness-copilot origin/main"
        ]
      },
      {
        "allowed_files": [
          "code_review_graph/**",
          "tests/**",
          "README.md",
          "docs/**"
        ],
        "branch": "codex/code-review-contract-20260626-importer-source-readiness-copilot",
        "forbidden_files": [
          "pyproject.toml unless dependency changes are required"
        ],
        "goal": "Keep the stable JSON contract compatible with required sections and proof boundaries.",
        "handoff_required_fields": [
          "lane",
          "branch_or_worktree",
          "changed_files",
          "commands_run",
          "generated_artifacts",
          "blockers",
          "unsafe_or_external_gates",
          "next_valid_move",
          "commit",
          "push_state"
        ],
        "handoff_template": "templates/HANDOFF.md",
        "id": "code-review-contract",
        "mode": "reviewer",
        "proof_commands": [
          "uv run pytest tests/test_visualization.py -q",
          "uv run ruff check code_review_graph tests"
        ],
        "remote": "https://github.com/itsmeeChandU/code-review-graph-private.git",
        "repo_id": "code-review-graph",
        "repo_role": "code_contract_layer",
        "target_branch": "main",
        "worktree": "/Users/chandu/.codex/worktrees/ai-dev-os-workflow/code-review-graph-code-review-contract",
        "worktree_commands": [
          "git fetch origin",
          "git worktree add /Users/chandu/.codex/worktrees/ai-dev-os-workflow/code-review-graph-code-review-contract -b codex/code-review-contract-20260626-importer-source-readiness-copilot origin/main"
        ]
      },
      {
        "allowed_files": [
          "scripts/code_review_graph.py",
          "tests/test_code_review_graph.py",
          "data/intelligence/sourcecode_graph_contract.json"
        ],
        "branch": "codex/ih-contract-export-20260626-importer-source-readiness-copilot",
        "forbidden_files": [
          "app/**",
          "graph/**",
          "market_system/**",
          "venture_studio/**"
        ],
        "goal": "Export the code-review graph contract without changing product logic.",
        "handoff_required_fields": [
          "lane",
          "branch_or_worktree",
          "changed_files",
          "commands_run",
          "generated_artifacts",
          "blockers",
          "unsafe_or_external_gates",
          "next_valid_move",
          "commit",
          "push_state"
        ],
        "handoff_template": "templates/HANDOFF.md",
        "id": "ih-contract-export",
        "mode": "surgeon",
        "proof_commands": [
          "/Users/chandu/Workspace/Finance/intelligence-hub/.venv/bin/python -m pytest tests/test_code_review_graph.py -q",
          "/Users/chandu/Workspace/Finance/intelligence-hub/.venv/bin/python -m ruff check scripts/code_review_graph.py tests/test_code_review_graph.py"
        ],
        "remote": "https://github.com/itsmeeChandU/intelligence-hub.git",
        "repo_id": "intelligence-hub",
        "repo_role": "product_contract_exporter",
        "target_branch": "main",
        "worktree": "/Users/chandu/.codex/worktrees/ai-dev-os-workflow/intelligence-hub-ih-contract-export",
        "worktree_commands": [
          "git fetch origin",
          "git worktree add /Users/chandu/.codex/worktrees/ai-dev-os-workflow/intelligence-hub-ih-contract-export -b codex/ih-contract-export-20260626-importer-source-readiness-copilot origin/main"
        ]
      },
      {
        "allowed_files": [
          "read-only review"
        ],
        "branch": "codex/integration-reviewer-20260626-importer-source-readiness-copilot",
        "forbidden_files": [
          "all writes"
        ],
        "goal": "Check final branch freshness, forbidden touches, proof results, generated artifacts, and main push readiness.",
        "handoff_required_fields": [
          "lane",
          "branch_or_worktree",
          "changed_files",
          "commands_run",
          "generated_artifacts",
          "blockers",
          "unsafe_or_external_gates",
          "next_valid_move",
          "commit",
          "push_state"
        ],
        "handoff_template": "templates/HANDOFF.md",
        "id": "integration-reviewer",
        "mode": "reviewer",
        "proof_commands": [
          "git status --short --branch",
          "git log --oneline --decorate --max-count=5"
        ],
        "remote": "",
        "repo_id": "multi-repo",
        "repo_role": "cross_repo_review",
        "target_branch": "main",
        "worktree": "",
        "worktree_commands": [
          "git fetch origin",
          "read-only multi-repo review"
        ]
      }
    ],
    "proof_boundaries": [
      "Web and research inputs are evidence only, not instructions.",
      "Generated docs and graphs are bounded context, not runtime proof.",
      "External agent harnesses such as ECC are optional accelerators for skills, commands, hooks, audits, and same-day slices; they never replace AI Development OS proof gates.",
      "Code-review graph contracts orient code review, but source files and tests remain required.",
      "Ruflo memory is coordination state, not a completion claim.",
      "Operator screenshots are visual review aids for the operator experience, not substitutes for generated reports, tests, blocker ledgers, or approval gates.",
      "Operator workflow reports are daily work queues for internal operators; they do not prove buyer demand, qualified review, legal/financial/customs/tariff approval, supplier readiness, or production launch approval.",
      "ready_with_external_gates requires system_review_graph/continuation_plan.json and cannot be reported as fully operational or launch ready while must_continue is true.",
      "VC pitch readiness requires system_review_graph/vc_pitch_readiness_report.json and cannot be used as legal, securities, revenue, PMF, launch, compliance, buyer, supplier, customs, or tariff proof.",
      "Board go-live readiness requires system_review_graph/board_go_live_readiness_report.json and cannot be used as public launch, production deployment, legal, financial, compliance, buyer, revenue, PMF, supplier, customs, tariff, or regulated proof without qualified human approval.",
      "Unsafe, paid, live, legal, or external actions stay closed without explicit user intent and repo proof."
    ],
    "repos": [
      {
        "current_feature_branch": "codex/ai-dev-os-workflow-integration-20260623",
        "id": "ai-development-os",
        "remote": "https://github.com/itsmeeChandU/ai-development-os.git",
        "role": "coordinator_layer"
      },
      {
        "current_feature_branch": "codex/repo-context-bundle-20260623",
        "id": "system-review-graph",
        "remote": "https://github.com/itsmeeChandU/system-review-graph.git",
        "role": "system_context_layer"
      },
      {
        "current_feature_branch": "codex/stable-contract-export-20260623",
        "id": "code-review-graph",
        "remote": "https://github.com/itsmeeChandU/code-review-graph-private.git",
        "role": "code_contract_layer",
        "upstream": "https://github.com/tirth8205/code-review-graph.git"
      },
      {
        "current_feature_branch": "codex/code-review-graph-contract-20260623",
        "id": "intelligence-hub",
        "remote": "https://github.com/itsmeeChandU/intelligence-hub.git",
        "role": "product_contract_exporter"
      },
      {
        "current_feature_branch": "main",
        "id": "importer-source-readiness-copilot",
        "remote": "https://github.com/itsmeeChandU/importer-source-readiness-copilot.git",
        "role": "product_implementation_target"
      }
    ],
    "run_id": "20260626-importer-source-readiness-copilot",
    "slash_commands": [
      {
        "command": "/ados:normalize",
        "id": "normalize",
        "mode": "architect",
        "outputs": [
          "instruction_contract",
          "complexity_classification",
          "first_next_action"
        ],
        "proof_gates": [
          "repo_status_checked",
          "constraints_written"
        ],
        "purpose": "Convert a fuzzy idea or evolving instruction into a task contract.",
        "required_inputs": [
          "user_request",
          "repo_path"
        ]
      },
      {
        "command": "/ados:context-bundle",
        "id": "context-bundle",
        "mode": "architect",
        "outputs": [
          "repo_context_bundle",
          "proof_boundaries"
        ],
        "proof_gates": [
          "missing_context_has_next_valid_move"
        ],
        "purpose": "Load bounded SRG, documentation graph, and code-review graph context before lane assignment.",
        "required_inputs": [
          "srg_manifest",
          "optional_documentation_graph",
          "optional_code_review_graph_contract"
        ]
      },
      {
        "command": "/ados:repo-intake",
        "id": "repo-intake",
        "mode": "architect",
        "outputs": [
          "internal_repo_intake_packet",
          "repo_blockers"
        ],
        "proof_gates": [
          "repo_registered",
          "target_repo_selected_or_blocked"
        ],
        "purpose": "Select internal/helper repos, product repo target, and repo-truth boundaries before lanes.",
        "required_inputs": [
          "idea_source",
          "target_repo"
        ]
      },
      {
        "command": "/ados:research-plan",
        "id": "research-plan",
        "mode": "research",
        "outputs": [
          "research_data_plan",
          "research_blockers",
          "data_blockers"
        ],
        "proof_gates": [
          "research_depth_selected",
          "external_gates_written"
        ],
        "purpose": "Decide model-prior, web, official-source, dataset, deep-research, and expert-validation depth.",
        "required_inputs": [
          "problem",
          "domain",
          "data_need"
        ]
      },
      {
        "command": "/ados:strategy-plan",
        "id": "strategy-plan",
        "mode": "architect",
        "outputs": [
          "development_strategy_plan",
          "external_contract_blockers",
          "country_requirement_blockers"
        ],
        "proof_gates": [
          "development_mode_selected",
          "external_inputs_blocked_or_sourced"
        ],
        "purpose": "Choose the field-specific development mode, agents, proof gates, external contracts, and procurement/compliance blockers.",
        "required_inputs": [
          "idea",
          "field",
          "country"
        ]
      },
      {
        "command": "/ados:harness-intake",
        "id": "harness-intake",
        "mode": "architect",
        "outputs": [
          "external_harness_integration_packet",
          "adoption_blockers",
          "command_mapping"
        ],
        "proof_gates": [
          "official_source_recorded",
          "license_recorded",
          "blocked_effects_written",
          "security_gate_written"
        ],
        "purpose": "Map an optional external agent harness into AI Development OS without letting it replace proof gates.",
        "required_inputs": [
          "harness",
          "install_mode",
          "target_repo"
        ]
      },
      {
        "command": "/ados:lane",
        "id": "lane",
        "mode": "surgeon",
        "outputs": [
          "lane_packet",
          "worktree_commands",
          "handoff_template"
        ],
        "proof_gates": [
          "owned_files_declared",
          "forbidden_files_declared",
          "proof_commands_declared"
        ],
        "purpose": "Create a bounded worker packet with allowed files, forbidden files, proof commands, and handoff path.",
        "required_inputs": [
          "goal",
          "repo_id",
          "lane_id"
        ]
      },
      {
        "command": "/ados:proof",
        "id": "proof",
        "mode": "reviewer",
        "outputs": [
          "proof_result",
          "blocker_rows"
        ],
        "proof_gates": [
          "commands_recorded",
          "failures_have_next_valid_move"
        ],
        "purpose": "Run or inspect focused proof commands and generated artifact checks for one lane.",
        "required_inputs": [
          "lane_packet",
          "changed_files"
        ]
      },
      {
        "command": "/ados:review",
        "id": "review",
        "mode": "reviewer",
        "outputs": [
          "review_findings",
          "merge_blockers"
        ],
        "proof_gates": [
          "findings_have_file_refs",
          "residual_risk_written"
        ],
        "purpose": "Review a lane branch for regressions, missing proof, forbidden touches, and unsupported claims.",
        "required_inputs": [
          "branch",
          "base_branch",
          "handoff"
        ]
      },
      {
        "command": "/ados:merge",
        "id": "merge",
        "mode": "merge",
        "outputs": [
          "merge_result",
          "post_merge_proof",
          "push_ref"
        ],
        "proof_gates": [
          "branch_fresh",
          "post_merge_checks_pass"
        ],
        "purpose": "Integrate verified branches into the target branch and refresh final truth artifacts.",
        "required_inputs": [
          "verified_branch",
          "target_branch"
        ]
      },
      {
        "command": "/ados:goal",
        "id": "goal",
        "mode": "goal",
        "outputs": [
          "goal_status",
          "proof_summary",
          "remaining_blockers"
        ],
        "proof_gates": [
          "done_predicates_checked",
          "blockers_have_next_valid_move",
          "ready_with_external_gates_has_continuation_plan"
        ],
        "purpose": "Keep a long-running objective active across proof loops until complete or explicitly blocked.",
        "required_inputs": [
          "objective",
          "repos",
          "done_predicates"
        ]
      }
    ],
    "workflow_manifest": "manifests/agentic_workflow_manifest.json"
  },
  "generated_at": "2026-06-26T01:25:12+00:00",
  "kind": "prompt_to_product_packet",
  "next_valid_move": "Create or select the target repo, load bounded context, claim the first lane, and run its proof commands.",
  "normalized_contract": {
    "constraints": [
      "Use repo truth over chat memory.",
      "Keep unsafe, paid, legal, live, or external effects closed by default.",
      "Produce code/data/tests/generated artifacts or a blocker row.",
      "Treat AI model subject expertise as a first-pass hypothesis until external evidence or experts validate high-impact claims."
    ],
    "evidence_required": [
      "git branch/status proof",
      "system review graph or context bundle",
      "code-review graph contract when source scope is broad",
      "research/data plan with source, data, and expert gates",
      "development strategy plan for the product field",
      "focused tests or smoke checks",
      "handoff with next_valid_move"
    ],
    "first_action": "Emit lane packet and run the smallest proof loop.",
    "goal": "Canada-focused importer source readiness copilot with startup lifecycle R&D, operator screenshot evidence, and board go-live gates"
  },
  "product": {
    "complexity": {
      "level": "S2",
      "reason": "data, API, credential, or source dependency present"
    },
    "idea": "Canada-focused importer source readiness copilot with startup lifecycle R&D, operator screenshot evidence, and board go-live gates",
    "name": "importer-source-readiness-copilot"
  },
  "repo_intake": {
    "blockers": [],
    "generated_at": "2026-06-26T01:25:12+00:00",
    "idea_source": {
      "allowed_use": "Generate startup/app ideas, export source graph contracts, and host product-boundary truth surfaces.",
      "branch_rule": "main plus codex/* product or contract branches",
      "id": "intelligence-hub",
      "proof_commands": [
        "/Users/chandu/Workspace/Finance/intelligence-hub/.venv/bin/python -m pytest tests/test_code_review_graph.py -q"
      ],
      "remote": "https://github.com/itsmeeChandU/intelligence-hub.git",
      "required_context": [
        "sourcecode_graph_contract.json",
        "Venture Studio idea packet when available"
      ],
      "role": "idea_source_and_product_boundary"
    },
    "intake_rules": [
      "Treat user or Intelligence Hub idea packets as claims until repo evidence and research/data routes validate them.",
      "Select existing internal repos only when their role matches the product lane.",
      "Create a new private product repo when the idea should not modify an existing product boundary.",
      "Keep Ruflo as coordination memory only; do not use it as repo truth.",
      "Write missing repo access, missing credentials, missing data, or missing expert review as blocker rows with next_valid_move."
    ],
    "kind": "internal_repo_intake",
    "next_valid_move": "Load source idea packet, select product target repo, then emit lane packet.",
    "repo_groups": [
      {
        "description": "Repos or systems that can originate startup/application ideas.",
        "id": "idea_sources",
        "repos": [
          "intelligence-hub"
        ]
      },
      {
        "description": "Repos that normalize, route, schedule, and prove prompt-to-product work.",
        "id": "coordination_layer",
        "repos": [
          "ai-development-os"
        ]
      },
      {
        "description": "Repos that provide bounded system and code context for agents.",
        "id": "context_layers",
        "repos": [
          "system-review-graph",
          "code-review-graph"
        ]
      },
      {
        "description": "Repos that may contain product implementation, generated source truth, or downstream app work.",
        "id": "product_repos",
        "repos": [
          "intelligence-hub",
          "importer-source-readiness-copilot",
          "future-product-repo"
        ]
      }
    ],
    "status": "ready",
    "target_repo": {
      "allowed_use": "Hold the actual importer/exporter source readiness product implementation, continuation lanes, VC pitch packet, board go-live packet, operator workflow queue, and proof artifacts.",
      "branch_rule": "main plus codex/* product branches",
      "id": "importer-source-readiness-copilot",
      "proof_commands": [
        "python3 scripts/check_product.py",
        "python3 scripts/run_external_gates.py",
        "python3 scripts/export_operator_dashboard.py",
        "python3 scripts/plan_continuation.py",
        "python3 scripts/build_vc_pitch_packet.py",
        "python3 scripts/build_board_go_live_packet.py",
        "python3 scripts/run_operator_workflow.py",
        "python3 -m unittest discover -s tests -p 'test_*.py'"
      ],
      "remote": "https://github.com/itsmeeChandU/importer-source-readiness-copilot.git",
      "required_context": [
        "AGENTS.md",
        "docs/PRODUCT_STATUS.md",
        "docs/STARTUP_LIFECYCLE.md",
        "docs/OPERATOR_GUIDE.md",
        "system_review_graph/readiness_report.json",
        "system_review_graph/external_gate_report.json",
        "system_review_graph/continuation_plan.json",
        "system_review_graph/vc_pitch_readiness_report.json",
        "system_review_graph/board_go_live_readiness_report.json",
        "system_review_graph/operator_workflow_report.json",
        "system_review_graph/operator_screenshot_manifest.json",
        "system_review_graph/operator_dashboard.html"
      ],
      "role": "product_implementation_target"
    }
  },
  "research_data_plan": {
    "blockers": [
      {
        "evidence": "manifests/research_data_router.json",
        "gate": "closed",
        "id": "research:r5_expert_or_user_validation:external-input",
        "issue": "external data or human validation is required before final product claims",
        "module": "research_data_router",
        "next_valid_move": "Create the source/expert plan and collect dated evidence.",
        "owner": "research",
        "unsafe_to_bypass": true
      }
    ],
    "data_need": "",
    "data_routes": [
      {
        "allowed_sources": [
          "local fixtures",
          "synthetic examples"
        ],
        "blocker_if_missing": false,
        "id": "D0_NO_EXTERNAL_DATA",
        "use_when": "Prototype logic can be proven with fixtures or static examples."
      },
      {
        "allowed_sources": [
          "official docs",
          "standards",
          "regulatory pages",
          "vendor docs"
        ],
        "blocker_if_missing": true,
        "id": "D2_PRIMARY_OFFICIAL_SOURCE",
        "use_when": "Need official docs, API specs, legal/regulatory pages, standards, pricing, or vendor guarantees."
      },
      {
        "allowed_sources": [
          "subject expert",
          "buyer/user interview",
          "qualified reviewer"
        ],
        "blocker_if_missing": true,
        "id": "D4_HUMAN_EXPERT_OR_USER",
        "use_when": "Need buyer truth, operational workflow truth, clinical/legal/financial judgment, safety review, or final domain direction."
      }
    ],
    "domain": "import_export",
    "expert_validation_rule": "After the product is substantially built, talk to actual people, users, buyers, operators, or qualified subject experts. Their feedback becomes correction evidence for the next product loop.",
    "generated_at": "2026-06-26T01:25:12+00:00",
    "kind": "research_data_plan",
    "next_valid_move": "Run model-prior synthesis, then collect the listed external evidence before final claims.",
    "problem": "Canada-focused importer source readiness copilot with startup lifecycle R&D, operator screenshot evidence, and board go-live gates",
    "research_depths": [
      {
        "id": "R0_MODEL_PRIOR",
        "proof_boundary": "AI synthesis is a working hypothesis, not external-world proof.",
        "rate_tier": "none",
        "required_artifacts": [
          "instruction contract",
          "assumptions list"
        ],
        "use_when": "Stable general knowledge, small local products, no current facts, no regulated claims."
      },
      {
        "id": "R2_OFFICIAL_SOURCE_REVIEW",
        "proof_boundary": "Prefer primary/official sources for implementation and compliance-sensitive facts.",
        "rate_tier": "medium",
        "required_artifacts": [
          "official-source record",
          "license/access notes",
          "proof commands"
        ],
        "use_when": "APIs, SDKs, library behavior, pricing, rules, docs, regulations, standards, or vendor claims."
      },
      {
        "id": "R4_DEEP_RESEARCH",
        "proof_boundary": "Detailed research informs architecture and scope; it still does not prove demand or expert correctness.",
        "rate_tier": "high",
        "required_artifacts": [
          "deep research brief",
          "source comparison",
          "decision record",
          "remaining unknowns"
        ],
        "use_when": "Ambiguous problem statements, unfamiliar domains, technical feasibility uncertainty, market structure uncertainty, or multi-source synthesis."
      },
      {
        "id": "R5_EXPERT_OR_USER_VALIDATION",
        "proof_boundary": "AI can produce the first hypothesis. Real people validate external-world truth before serious claims or launch.",
        "rate_tier": "external_gate",
        "required_artifacts": [
          "expert/user interview plan",
          "dated feedback",
          "claim corrections",
          "launch blocker decision"
        ],
        "use_when": "Medical, legal, financial, safety-critical, public claims, high-risk domain judgment, buyer demand, workflow correctness, or final subject-matter direction."
      }
    ],
    "routing_rules": [
      "Start with R0 model-prior synthesis for ideation unless the problem is current, data-dependent, ambiguous, regulated, or externally claimed.",
      "Use R1 when normal web freshness or public market/examples matter.",
      "Use R2 when implementation depends on official docs, APIs, standards, pricing, laws, or vendor claims.",
      "Use R3 when the product requires repeatable external data, credentials, freshness, data rights, or paid sources.",
      "Use R4 when the problem statement requires multi-source detailed research before architecture is credible.",
      "Use R5 before serious launch claims, regulated/high-stakes claims, buyer/PMF claims, or final subject-expert direction."
    ],
    "status": "ready_with_external_gates"
  },
  "slash_commands": [
    "/ados:normalize",
    "/ados:context-bundle",
    "/ados:lane",
    "/ados:proof",
    "/ados:review",
    "/ados:merge",
    "/ados:goal",
    "/ados:repo-intake",
    "/ados:research-plan",
    "/ados:strategy-plan",
    "/ados:harness-intake"
  ]
}
```
