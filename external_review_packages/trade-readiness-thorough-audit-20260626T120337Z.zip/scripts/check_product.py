#!/usr/bin/env python3
"""Run the standalone product proof gate."""

from __future__ import annotations

import json
import sqlite3
import subprocess
import sys
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parent.parent
REQUIRED_BLOCKER_FIELDS = {
    "id",
    "module",
    "issue",
    "owner",
    "evidence",
    "gate",
    "next_valid_move",
    "unsafe_to_bypass",
}
VALID_GATES = {"closed", "open", "not_applicable"}


def _run(command: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run(command, cwd=ROOT, text=True, capture_output=True, check=False)


def _load_json(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _validate_blockers(path: Path) -> list[str]:
    errors: list[str] = []
    if not path.exists():
        return [f"missing blocker ledger: {path.relative_to(ROOT)}"]

    for line_number, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        if not line.strip():
            continue
        try:
            row = json.loads(line)
        except json.JSONDecodeError as exc:
            errors.append(f"blockers.jsonl:{line_number}: invalid JSON: {exc}")
            continue
        missing = sorted(REQUIRED_BLOCKER_FIELDS - set(row))
        if missing:
            errors.append(f"blockers.jsonl:{line_number}: missing {', '.join(missing)}")
        if row.get("gate") not in VALID_GATES:
            errors.append(f"blockers.jsonl:{line_number}: invalid gate {row.get('gate')!r}")
    return errors


def _validate_blocker_rows(rows: list[dict[str, Any]], label: str) -> list[str]:
    errors: list[str] = []
    for index, row in enumerate(rows, start=1):
        missing = sorted(REQUIRED_BLOCKER_FIELDS - set(row))
        if missing:
            errors.append(f"{label}:{index}: missing {', '.join(missing)}")
        if row.get("gate") not in VALID_GATES:
            errors.append(f"{label}:{index}: invalid gate {row.get('gate')!r}")
    return errors


def main() -> int:
    commands = [
        [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"],
        [sys.executable, "scripts/run_readiness.py"],
        [sys.executable, "scripts/run_external_gates.py"],
        [sys.executable, "scripts/plan_continuation.py"],
        [sys.executable, "scripts/build_vc_pitch_packet.py"],
        [sys.executable, "scripts/build_board_go_live_packet.py"],
        [sys.executable, "scripts/run_operator_workflow.py"],
        [sys.executable, "scripts/run_customer_workflow.py"],
        [sys.executable, "scripts/run_policy_intelligence.py"],
        [sys.executable, "scripts/run_completion_platform.py"],
        [sys.executable, "scripts/run_product_operations.py"],
        [sys.executable, "scripts/export_operator_dashboard.py"],
        [sys.executable, "scripts/audit_external_package.py", "--root", "."],
    ]
    for command in commands:
        result = _run(command)
        if result.returncode != 0:
            print("Product check: FAIL")
            print(f"command: {' '.join(command)}")
            print(result.stdout)
            print(result.stderr)
            return result.returncode

    report_path = ROOT / "system_review_graph" / "readiness_report.json"
    report = _load_json(report_path)
    external = _load_json(ROOT / "system_review_graph" / "external_gate_report.json")
    continuation = _load_json(ROOT / "system_review_graph" / "continuation_plan.json")
    vc_pitch = _load_json(ROOT / "system_review_graph" / "vc_pitch_readiness_report.json")
    board = _load_json(ROOT / "system_review_graph" / "board_go_live_readiness_report.json")
    workflow = _load_json(ROOT / "system_review_graph" / "operator_workflow_report.json")
    customer = _load_json(ROOT / "system_review_graph" / "customer_readiness_report.json")
    evidence_ledger = _load_json(ROOT / "system_review_graph" / "evidence_ledger.json")
    runtime = _load_json(ROOT / "system_review_graph" / "product_runtime_state.json")
    auth_rbac = _load_json(ROOT / "system_review_graph" / "auth_rbac_matrix.json")
    claims_gate = _load_json(ROOT / "system_review_graph" / "claims_gate_matrix.json")
    review_requests = _load_json(ROOT / "system_review_graph" / "review_requests.json")
    audit_events = _load_json(ROOT / "system_review_graph" / "audit_events.json")
    deployment = _load_json(ROOT / "system_review_graph" / "deployment_readiness_report.json")
    ai_data_policy = _load_json(ROOT / "system_review_graph" / "ai_data_policy.json")
    ai_model_router = _load_json(ROOT / "system_review_graph" / "ai_model_router.json")
    redaction_pipeline = _load_json(ROOT / "system_review_graph" / "redaction_pipeline.json")
    manual_no_ai_workflow = _load_json(ROOT / "system_review_graph" / "manual_no_ai_workflow.json")
    requirements_traceability = _load_json(ROOT / "system_review_graph" / "requirements_traceability_matrix.json")
    public_trade = _load_json(ROOT / "system_review_graph" / "public_trade_readiness_manifest.json")
    exporter_mode = _load_json(ROOT / "system_review_graph" / "exporter_mode_requirements.json")
    public_reports = _load_json(ROOT / "system_review_graph" / "public_report_types.json")
    public_upload_policy = _load_json(ROOT / "system_review_graph" / "public_upload_policy.json")
    policy_monitor = _load_json(ROOT / "system_review_graph" / "intelligence_hub_policy_monitor.json")
    policy_snapshots = _load_json(ROOT / "system_review_graph" / "policy_source_snapshots.json")
    policy_impact = _load_json(ROOT / "system_review_graph" / "policy_change_impact_report.json")
    completion = _load_json(ROOT / "system_review_graph" / "completion_platform_manifest.json")
    country_coverage = _load_json(ROOT / "system_review_graph" / "country_coverage_report.json")
    opportunity_scanner = _load_json(ROOT / "system_review_graph" / "opportunity_scanner_report.json")
    transport_readiness = _load_json(ROOT / "system_review_graph" / "transport_readiness_report.json")
    billing_controls = _load_json(ROOT / "system_review_graph" / "billing_credit_controls.json")
    agent_api = _load_json(ROOT / "system_review_graph" / "agent_api_manifest.json")
    traffic_pages = _load_json(ROOT / "system_review_graph" / "traffic_pages_manifest.json")
    research_execution = _load_json(ROOT / "system_review_graph" / "research_execution_plan.json")
    team_workspace = _load_json(ROOT / "system_review_graph" / "team_workspace_report.json")
    expert_network = _load_json(ROOT / "system_review_graph" / "expert_network_report.json")
    billing_usage = _load_json(ROOT / "system_review_graph" / "billing_usage_ledger.json")
    agent_gateway = _load_json(ROOT / "system_review_graph" / "agent_api_gateway_contract.json")
    launch_operations = _load_json(ROOT / "system_review_graph" / "launch_operations_report.json")
    all_stages = _load_json(ROOT / "system_review_graph" / "all_stage_readiness_report.json")
    product_operations = _load_json(ROOT / "system_review_graph" / "product_operations_report.json")
    research_runs = _load_json(ROOT / "system_review_graph" / "research_execution_runs.json")
    expert_work_orders = _load_json(ROOT / "system_review_graph" / "expert_review_work_orders.json")
    team_activity = _load_json(ROOT / "system_review_graph" / "team_workspace_activity.json")
    launch_events = _load_json(ROOT / "system_review_graph" / "launch_operations_events.json")
    screenshot_manifest_path = ROOT / "system_review_graph" / "operator_screenshot_manifest.json"
    screenshot_manifest = _load_json(screenshot_manifest_path) if screenshot_manifest_path.exists() else {}
    expected = {
        "status": "ready_with_external_gates",
        "row_count": 2,
        "blocker_count": 9,
        "blocked_unsafe_rows": 0,
    }
    failures = [
        f"{key} expected {value!r}, got {report.get(key)!r}"
        for key, value in expected.items()
        if report.get(key) != value
    ]
    if external.get("status") != "ready_with_external_gates":
        failures.append(f"external gate status expected ready_with_external_gates, got {external.get('status')!r}")
    if external.get("blocker_count", 0) < 10:
        failures.append("external gate report should include country, buyer, expert, contract, data, and launch blockers")
    if not (ROOT / "system_review_graph" / "operator_dashboard.html").exists():
        failures.append("operator dashboard was not generated")
    else:
        dashboard_html = (ROOT / "system_review_graph" / "operator_dashboard.html").read_text(encoding="utf-8")
        if "Operator Screenshots" not in dashboard_html:
            failures.append("operator dashboard should include the screenshot gallery")
        if "Operator Work Queue" not in dashboard_html:
            failures.append("operator dashboard should include the operator work queue")
        if "Canada Tools" not in dashboard_html:
            failures.append("operator dashboard should link Canadian tool references")
        if "Customer Source Packet Workflow" not in dashboard_html:
            failures.append("operator dashboard should include the customer source-packet workflow")
        if "/packets/packet-frozen-tuna-canada-001" not in dashboard_html:
            failures.append("operator dashboard should link the customer source-packet route")
        if "Path To Private Beta" not in dashboard_html:
            failures.append("operator dashboard should include the private beta path")
        if "Internal logic ready - external claims blocked" not in dashboard_html:
            failures.append("operator dashboard should use safe customer-facing status language")
    for path in (
        "scripts/serve_operator_app.py",
        "src/importer_source_readiness/operator_app.py",
        "src/importer_source_readiness/source_packet_workflow.py",
        "src/importer_source_readiness/customer_store.py",
        "src/importer_source_readiness/product_runtime.py",
        "src/importer_source_readiness/document_processing.py",
        "src/importer_source_readiness/policy_intelligence.py",
        "src/importer_source_readiness/completion_platform.py",
        "src/importer_source_readiness/product_operations.py",
        "src/importer_source_readiness/ai_review_validation.py",
        "tests/test_operator_app.py",
        "tests/test_source_packet_workflow.py",
        "tests/test_customer_store.py",
        "tests/test_product_runtime.py",
        "tests/test_completion_platform.py",
        "tests/test_external_package_audit.py",
        "scripts/run_customer_workflow.py",
        "scripts/run_policy_intelligence.py",
        "scripts/run_completion_platform.py",
        "scripts/run_product_operations.py",
        "scripts/audit_external_package.py",
        "data/customer_source_packets.json",
        "data/evidence_ledger.json",
        "CUSTOMER_SOURCE_PACKET_SPEC.md",
        "SOURCE_OF_TRUTH.md",
        "RUN_RESULTS.md",
        "REDACTION_REPORT.md",
        "REVIEW_USE_TERMS.md",
        "OFFLINE_REPRODUCTION.md",
        "PACKAGE_AUDIT.md",
        "system_review_graph/customer_readiness_report.json",
        "system_review_graph/customer_readiness_report.md",
        "system_review_graph/customer_source_packets.json",
        "system_review_graph/evidence_ledger.json",
        "system_review_graph/customer_ai_review_runs.json",
        "system_review_graph/customer_workflow.sqlite",
        "system_review_graph/product_runtime_state.json",
        "system_review_graph/auth_rbac_matrix.json",
        "system_review_graph/claims_gate_matrix.json",
        "system_review_graph/review_requests.json",
        "system_review_graph/human_review_findings.json",
        "system_review_graph/report_exports.json",
        "system_review_graph/audit_events.json",
        "system_review_graph/deletion_requests.json",
        "system_review_graph/deployment_readiness_report.json",
        "system_review_graph/private_beta_readiness_checklist.json",
        "system_review_graph/ai_data_policy.json",
        "system_review_graph/model_endpoints.json",
        "system_review_graph/ai_model_router.json",
        "system_review_graph/redaction_pipeline.json",
        "system_review_graph/manual_no_ai_workflow.json",
        "system_review_graph/requirements_traceability_matrix.json",
        "system_review_graph/public_trade_readiness_manifest.json",
        "system_review_graph/exporter_mode_requirements.json",
        "system_review_graph/public_report_types.json",
        "system_review_graph/public_upload_policy.json",
        "system_review_graph/intelligence_hub_policy_monitor.json",
        "system_review_graph/policy_source_snapshots.json",
        "system_review_graph/policy_change_impact_report.json",
        "system_review_graph/policy_intelligence.sqlite",
        "system_review_graph/completion_platform_manifest.json",
        "system_review_graph/country_coverage_report.json",
        "system_review_graph/opportunity_scanner_report.json",
        "system_review_graph/transport_readiness_report.json",
        "system_review_graph/billing_credit_controls.json",
        "system_review_graph/agent_api_manifest.json",
        "system_review_graph/traffic_pages_manifest.json",
        "system_review_graph/research_execution_plan.json",
        "system_review_graph/team_workspace_report.json",
        "system_review_graph/expert_network_report.json",
        "system_review_graph/billing_usage_ledger.json",
        "system_review_graph/agent_api_gateway_contract.json",
        "system_review_graph/launch_operations_report.json",
        "system_review_graph/all_stage_readiness_report.json",
        "system_review_graph/product_operations_report.json",
        "system_review_graph/product_operations_log.json",
        "system_review_graph/research_execution_runs.json",
        "system_review_graph/expert_review_work_orders.json",
        "system_review_graph/team_workspace_activity.json",
        "system_review_graph/launch_operations_events.json",
        "system_review_graph/generated_reports/data_intake_packet-frozen-tuna-canada-001.json",
        "system_review_graph/generated_reports/missing_evidence_packet-frozen-tuna-canada-001.json",
        "system_review_graph/generated_reports/starter_checklist_packet-frozen-tuna-canada-001.json",
        "system_review_graph/generated_reports/chatgpt_safe_summary_packet-frozen-tuna-canada-001.json",
        "system_review_graph/generated_reports/broker_packet_packet-frozen-tuna-canada-001.json",
        "system_review_graph/source_refresh_runs.json",
        "system_review_graph/source_refresh_report_packet-frozen-tuna-canada-001.json",
        "system_review_graph/expert_review_packet_packet-frozen-tuna-canada-001.md",
        "migrations/0001_product_runtime.sql",
        "Dockerfile",
        "compose.yaml",
        ".env.example",
        "docs/PUBLIC_TRADE_READINESS.md",
        "docs/ALL_STAGES_COMPLETION.md",
        "docs/AI_DATA_POLICY.md",
        "docs/DOCUMENT_PROCESSING.md",
        "docs/OPPORTUNITY_SCANNER.md",
        "docs/POLICY_MONITORING.md",
        "docs/AGENT_API.md",
        "docs/SECURITY_PRIVACY.md",
        "docs/DEPLOYMENT.md",
    ):
        if not (ROOT / path).exists():
            failures.append(f"missing required product file: {path}")
    if not screenshot_manifest_path.exists():
        failures.append("operator screenshot manifest was not generated")
    if screenshot_manifest.get("status") != "screenshots_ready":
        failures.append("operator screenshot manifest should have screenshots_ready status")
    if screenshot_manifest.get("screenshot_count", 0) < 1:
        failures.append("operator screenshot manifest should include at least one generated screenshot")
    if "proof_boundary" not in screenshot_manifest:
        failures.append("operator screenshot manifest must include a proof boundary")
    if continuation.get("status") != "startup_in_progress":
        failures.append(f"continuation status expected startup_in_progress, got {continuation.get('status')!r}")
    if continuation.get("must_continue") is not True:
        failures.append("continuation plan must require continued evidence lanes")
    if continuation.get("lane_count", 0) < 5:
        failures.append("continuation plan should include buyer, compliance, country, data, contract, screening, and launch lanes")
    closed_claims = set(continuation.get("closed_claims", []))
    for claim in ("fully_operational", "launch_ready", "commercially_ready"):
        if claim not in closed_claims:
            failures.append(f"continuation plan must keep {claim} closed")
    if vc_pitch.get("status") != "vc_pitch_ready_with_diligence_gates":
        failures.append(f"VC pitch status expected ready with diligence gates, got {vc_pitch.get('status')!r}")
    if len(vc_pitch.get("diligence_lanes", [])) < 6:
        failures.append("VC pitch packet should include buyer, design-partner, compliance, data, business, and legal diligence lanes")
    pitch_closed_claims = set(vc_pitch.get("closed_claims", []))
    for claim in ("fully_operational", "public_launch_ready", "revenue_proven"):
        if claim not in pitch_closed_claims:
            failures.append(f"VC pitch packet must keep {claim} closed")
    for path in (
        "investor/vc_pitch_deck.md",
        "investor/one_pager.md",
        "investor/demo_script.md",
        "investor/diligence_room_index.md",
        "board/board_go_live_brief.md",
        "board/expert_review_packet.md",
        "board/launch_control_checklist.md",
        "board/financial_operating_model.md",
    ):
        if not (ROOT / path).exists():
            failures.append(f"missing pitch or board artifact: {path}")
    if board.get("status") != "board_go_live_candidate_with_human_approval_gates":
        failures.append(f"board go-live status expected candidate with human gates, got {board.get('status')!r}")
    if board.get("primary_market") != "Canada":
        failures.append(f"board go-live primary market expected Canada, got {board.get('primary_market')!r}")
    if board.get("human_approval_gate_count", 0) < 10:
        failures.append("board go-live packet should include simulated expert and launch human approval gates")
    for key in ("canadian_tools_ready", "simulated_expert_reviews_ready", "launch_controls_ready"):
        if board.get(key) is not True:
            failures.append(f"board go-live packet expected {key}=true")
    board_closed_claims = set(board.get("closed_claims", []))
    for claim in ("public_launch_ready", "legal_advice_ready", "financial_advice_ready"):
        if claim not in board_closed_claims:
            failures.append(f"board go-live packet must keep {claim} closed")
    if workflow.get("status") != "operator_workflow_ready_internal":
        failures.append(f"operator workflow expected internal ready, got {workflow.get('status')!r}")
    if workflow.get("operator_can_use_now") is not True:
        failures.append("operator workflow should be usable for internal review now")
    if workflow.get("work_queue_count", 0) < 20:
        failures.append("operator workflow should include source, gate, lane, and human-approval rows")
    workflow_types = set(workflow.get("work_queue_counts_by_type", {}))
    for row_type in (
        "source_card_review",
        "external_evidence_gate",
        "continuation_lane",
        "human_approval_gate",
    ):
        if row_type not in workflow_types:
            failures.append(f"operator workflow must include {row_type} rows")
    if workflow.get("unsafe_gates_closed") is not True:
        failures.append("operator workflow must keep unsafe gates closed")
    workflow_closed_claims = set(workflow.get("closed_claims", []))
    for claim in ("public_launch_ready", "customs_or_tariff_advice_ready", "supplier_recommendation_ready"):
        if claim not in workflow_closed_claims:
            failures.append(f"operator workflow must keep {claim} closed")
    if customer.get("status") != "customer_workflow_ready_internal":
        failures.append(f"customer workflow expected internal ready, got {customer.get('status')!r}")
    if customer.get("display_status") != "Internal logic ready - external claims blocked":
        failures.append(f"customer workflow display status is unsafe or unexpected: {customer.get('display_status')!r}")
    if customer.get("operator_display_status") != "Operator workbench usable for internal review":
        failures.append("customer workflow should expose operator workbench display status")
    if customer.get("customer_stage_status") != "Customer packet prototype active - real customer use not enabled":
        failures.append("customer workflow should expose customer prototype stage status")
    if customer.get("private_beta_status") != "blocked":
        failures.append("customer workflow should keep private beta blocked")
    if customer.get("packet_count", 0) < 1:
        failures.append("customer workflow should include at least one source packet")
    if customer.get("blocker_count", 0) < 1:
        failures.append("customer workflow must keep external-claim blockers visible")
    if len(customer.get("blocker_groups", [])) < 3:
        failures.append("customer workflow should consolidate blockers into grouped categories")
    if not customer.get("ai_review_runs"):
        failures.append("customer workflow should include AI simulated review runs")
    packet = customer.get("packets", [{}])[0]
    if not str(packet.get("customer_visible_status_label") or "").startswith("Blocked -"):
        failures.append("customer packet should remain blocked with customer-readable status")
    evidence_summary = packet.get("evidence_summary", {})
    if evidence_summary.get("attached", 0) < 3 or evidence_summary.get("missing", 0) < 4:
        failures.append("customer packet should expose evidence quality summary")
    if evidence_summary.get("ai_allowed", 0) < 1:
        failures.append("customer packet should expose AI permission summary")
    group_titles = {row.get("title") for row in packet.get("blocker_groups", [])}
    for group in ("Compliance Review", "Source Rights / Contract", "Buyer Validation"):
        if group not in group_titles:
            failures.append(f"customer packet should include grouped blocker {group}")
    customer_closed_claims = set(customer.get("blocked_claims", []))
    for claim in (
        "tariff_confirmed",
        "cfia_compliant",
        "supplier_recommended",
        "buyer_validated",
        "ready_to_import",
    ):
        if claim not in customer_closed_claims:
            failures.append(f"customer workflow must keep {claim} blocked")
    if evidence_ledger.get("status") != "evidence_ledger_ready_internal":
        failures.append(f"evidence ledger expected internal ready, got {evidence_ledger.get('status')!r}")
    if evidence_ledger.get("evidence_count", 0) < 3:
        failures.append("evidence ledger should include customer, CID, and official Canadian reference evidence")
    if "stale" not in evidence_ledger.get("counts_by_quality", {}):
        failures.append("evidence ledger should expose evidence quality counts")
    if not all("sensitivity_level" in row and "ai_processing_mode" in row for row in evidence_ledger.get("rows", [])):
        failures.append("evidence ledger should include sensitivity and AI permission fields")
    if runtime.get("status") != "private_beta_candidate_with_external_human_gates":
        failures.append(f"runtime state has unexpected status {runtime.get('status')!r}")
    if len(runtime.get("users", [])) < 4 or len(runtime.get("organizations", [])) < 3:
        failures.append("runtime state should include users and organizations")
    if "/api/auth/login" not in runtime.get("api_routes", []):
        failures.append("runtime state should expose auth API routes")
    if runtime.get("product") != "Trade Readiness Copilot":
        failures.append("runtime state should expose Trade Readiness Copilot as the public product")
    if runtime.get("internal_engine") != "Importer Source Readiness Copilot":
        failures.append("runtime state should preserve the internal engine name")
    if runtime.get("public_product_surface", {}).get("status") != "public_quick_check_ready_local_with_external_gates":
        failures.append("runtime state should expose the local public quick-check surface")
    for route in (
        "/start",
        "/tools/export-readiness",
        "/tools/document-check",
        "/opportunities",
        "/country-coverage",
        "/transport-readiness",
        "/reports/sample",
        "/pricing",
        "/billing",
        "/billing/usage",
        "/agent-api",
        "/stages",
        "/research-plan",
        "/expert-network",
        "/team-workspace",
        "/launch-operations",
        "/ai-data-policy",
        "/security",
        "/public/packets/:packetId/result",
        "/public/packets/:packetId/confirm",
        "/workspace",
        "/packets/:packetId/source-monitoring",
        "/packets/:packetId/safe-summary",
    ):
        if route not in runtime.get("ui_routes", {}).get("customer", []):
            failures.append(f"runtime state should expose public UI route {route}")
    for route in (
        "/api/public/starter",
        "/api/public/quick-check",
        "/api/public/packets/:id/confirm",
        "/api/public/packets/:id/chatgpt-safe-summary",
        "/api/public/packets/:id/reports/starter.pdf",
        "/api/public/packets/:id/reports/buyer.pdf",
        "/api/public/packets/:id/reports/broker.pdf",
        "/api/public/packets/:id/reports/missing.pdf",
        "/api/public/packets/:id/delete-files",
        "/api/opportunities",
        "/api/country-coverage",
        "/api/billing/controls",
        "/api/billing/usage",
        "/api/agent-api",
        "/api/agent-api/gateway",
        "/api/traffic-pages",
        "/api/transport-readiness",
        "/api/stages",
        "/api/research-plan",
        "/api/expert-network",
        "/api/team-workspace",
        "/api/launch-operations",
    ):
        if route not in runtime.get("api_routes", []):
            failures.append(f"runtime state should expose public API route {route}")
    if "/api/orgs/current/ai-policy" not in runtime.get("api_routes", []):
        failures.append("runtime state should expose AI policy API routes")
    if "/api/evidence/:evidenceId/ai-permission" not in runtime.get("api_routes", []):
        failures.append("runtime state should expose evidence AI permission API routes")
    if "/settings/ai-data-policy" not in runtime.get("ui_routes", {}).get("customer", []):
        failures.append("runtime state should expose customer AI policy settings route")
    if "/review/:reviewToken" not in runtime.get("ui_routes", {}).get("expert", []):
        failures.append("runtime state should expose scoped expert review routes")
    if runtime.get("security_controls", {}).get("organization_isolation") is None:
        failures.append("runtime state should describe organization isolation controls")
    if auth_rbac.get("security_controls", {}).get("rbac") is None:
        failures.append("auth/RBAC matrix should include RBAC controls")
    if claims_gate.get("blocked_by_default") is not True or len(claims_gate.get("claims", [])) < 6:
        failures.append("claims gate matrix should keep claims blocked by default")
    if not review_requests or review_requests[0].get("token") != "review-token-packet-frozen-tuna-canada-001":
        failures.append("review requests should include scoped frozen tuna review token")
    if len(audit_events.get("events", [])) < 3:
        failures.append("audit events should include packet, AI review, and report export events")
    if deployment.get("status") != "deployable_local_stack_ready_with_external_hosting_gates":
        failures.append("deployment readiness should describe hostable local stack with external gates")
    if ai_data_policy.get("status") != "ai_data_policy_ready" or len(ai_data_policy.get("policies", [])) < 2:
        failures.append("AI data policy artifact should expose organization policies")
    if ai_model_router.get("status") != "ai_model_router_ready" or not ai_model_router.get("route_decisions"):
        failures.append("AI model router artifact should expose route decisions")
    if redaction_pipeline.get("status") != "redaction_pipeline_ready" or "emails" not in redaction_pipeline.get("categories", []):
        failures.append("redaction pipeline artifact should expose redaction categories")
    if manual_no_ai_workflow.get("status") != "manual_no_ai_workflow_ready":
        failures.append("manual/no-AI workflow artifact should be ready")
    requirement_ids = {row.get("id") for row in requirements_traceability.get("requirements", [])}
    if len(requirements_traceability.get("requirements", [])) < 44:
        failures.append("requirements traceability matrix should cover public, exporter, policy, completion, all-stage, and operation requirements")
    for requirement_id in (
        "REQ-PUBLIC-01",
        "REQ-EXPORT-01",
        "REQ-EXPORT-09",
        "REQ-STARTER-01",
        "REQ-PDF-01",
        "REQ-CONFIRM-01",
        "REQ-IH-01",
        "REQ-OPPORTUNITY-01",
        "REQ-COVERAGE-01",
        "REQ-TRANSPORT-01",
        "REQ-BILLING-01",
        "REQ-AGENT-01",
        "REQ-TRAFFIC-01",
        "REQ-STAGE-01",
        "REQ-RESEARCH-01",
        "REQ-EXPERT-01",
        "REQ-TEAM-01",
        "REQ-API-GATEWAY-01",
        "REQ-LAUNCH-OPS-01",
        "REQ-OPERATIONS-01",
    ):
        if requirement_id not in requirement_ids:
            failures.append(f"requirements traceability matrix missing {requirement_id}")
    if public_trade.get("status") != "public_trade_readiness_ready_local":
        failures.append("public trade readiness manifest should be generated")
    if public_trade.get("public_product") != "Trade Readiness Copilot":
        failures.append("public trade readiness manifest should use the public product name")
    if "/api/public/quick-check" not in public_trade.get("routes", {}).get("api", []):
        failures.append("public trade readiness manifest should expose quick-check API")
    if "/api/public/starter" not in public_trade.get("routes", {}).get("api", []):
        failures.append("public trade readiness manifest should expose starter API")
    for route in (
        "/opportunities",
        "/country-coverage",
        "/transport-readiness",
        "/reports/sample",
        "/pricing",
        "/billing/usage",
        "/agent-api",
        "/stages",
        "/research-plan",
        "/expert-network",
        "/team-workspace",
        "/launch-operations",
        "/security",
        "/tools/document-check",
    ):
        if route not in public_trade.get("routes", {}).get("ui", []):
            failures.append(f"public trade readiness manifest should expose {route}")
    for route in (
        "/api/opportunities",
        "/api/country-coverage",
        "/api/billing/controls",
        "/api/billing/usage",
        "/api/agent-api",
        "/api/agent-api/gateway",
        "/api/traffic-pages",
        "/api/transport-readiness",
        "/api/stages",
        "/api/research-plan",
        "/api/expert-network",
        "/api/team-workspace",
        "/api/launch-operations",
    ):
        if route not in public_trade.get("routes", {}).get("api", []):
            failures.append(f"public trade readiness manifest should expose {route}")
    if "beginner_no_documents" not in public_trade.get("modes", {}):
        failures.append("public trade readiness manifest should expose beginner no-documents mode")
    if public_trade.get("intelligence_hub_policy_monitor", {}).get("status") != "database_style_contract_ready":
        failures.append("public manifest should expose the Intelligence Hub policy monitor contract")
    if "completion_stage_contracts" not in public_trade:
        failures.append("public manifest should expose completion-stage contracts")
    if exporter_mode.get("status") != "exporter_mode_requirements_ready":
        failures.append("exporter mode requirements manifest should be generated")
    if "exporter_side_readiness" not in exporter_mode.get("readiness_lanes", []):
        failures.append("exporter mode manifest should include exporter-side readiness lane")
    if "Broker Review Packet.pdf" not in public_reports.get("reports", []):
        failures.append("public report types should include Broker Review Packet.pdf")
    if "Starter Checklist.pdf" not in public_reports.get("reports", []):
        failures.append("public report types should include Starter Checklist.pdf")
    for report_name in ("Opportunity Research Report.pdf", "Policy Change Impact Report.pdf", "Broker/Freight-Forwarder Packet.pdf"):
        if report_name not in public_reports.get("reports", []):
            failures.append(f"public report types should include {report_name}")
    if public_upload_policy.get("notice_required") is not True:
        failures.append("public upload policy should require upload/AI notice")
    if public_upload_policy.get("quarantine") != "enabled":
        failures.append("public upload policy should quarantine public uploads")
    if public_upload_policy.get("direct_file_serving") is not False:
        failures.append("public upload policy should disable direct file serving")
    if public_upload_policy.get("user_confirmation_required") is not True:
        failures.append("public upload policy should require user confirmation")
    if policy_monitor.get("status") != "intelligence_hub_policy_monitor_ready_with_external_refresh_gates":
        failures.append("policy monitor should be generated with external refresh gates")
    if policy_monitor.get("integration_mode") != "database_style_local_contract":
        failures.append("policy monitor should use database-style local contract mode")
    if policy_monitor.get("monitored_source_count", 0) < 8:
        failures.append("policy monitor should include official Canadian source registry rows")
    if policy_monitor.get("stale_source_blocker_count", 0) < 1:
        failures.append("policy monitor should create stale-source blocker rows")
    if policy_snapshots.get("status") != "policy_source_snapshots_ready":
        failures.append("policy source snapshots artifact should be ready")
    if policy_impact.get("status") != "policy_change_impact_report_ready":
        failures.append("policy change impact report should be ready")
    if completion.get("status") != "all_local_stages_implemented_with_external_gates":
        failures.append(f"completion platform status unexpected: {completion.get('status')!r}")
    if country_coverage.get("status") != "country_coverage_ready_with_claim_gates":
        failures.append("country coverage report should be ready with claim gates")
    if opportunity_scanner.get("status") != "opportunity_scanner_ready_with_research_gates":
        failures.append("opportunity scanner should be ready with research gates")
    if opportunity_scanner.get("signal_count", 0) < 1:
        failures.append("opportunity scanner should include at least one signal row")
    if transport_readiness.get("status") != "transport_readiness_ready_with_forwarder_gates":
        failures.append("transport readiness should be ready with forwarder gates")
    if not transport_readiness.get("rows"):
        failures.append("transport readiness should include packet rows")
    if billing_controls.get("status") != "billing_credit_controls_ready_local_no_live_checkout":
        failures.append("billing controls should be local and no-live-checkout")
    if billing_controls.get("live_checkout_enabled") is not False:
        failures.append("billing controls must keep live checkout disabled")
    if agent_api.get("status") != "agent_api_manifest_ready_scoped_and_metered":
        failures.append("agent API manifest should be scoped and metered")
    forbidden_tools = set(agent_api.get("forbidden_tools", []))
    for tool in ("approve_import", "confirm_tariff", "validate_buyer", "ship_goods"):
        if tool not in forbidden_tools:
            failures.append(f"agent API manifest must forbid {tool}")
    if traffic_pages.get("status") != "traffic_pages_manifest_ready":
        failures.append("traffic pages manifest should be ready")
    if len(traffic_pages.get("pages", [])) < 10:
        failures.append("traffic pages manifest should include checklist and generator pages")
    if research_execution.get("status") != "research_execution_ready_with_evidence_gates":
        failures.append("research execution plan should be ready with evidence gates")
    if research_execution.get("operation_status") != "research_execution_operational_local_with_evidence_gates":
        failures.append("research execution should include local operation proof")
    if team_workspace.get("status") != "team_workspace_ready_local_with_approval_gates":
        failures.append("team workspace should be ready with approval gates")
    if team_workspace.get("operation_status") != "team_workspace_operational_local_with_approval_gates":
        failures.append("team workspace should include local operation proof")
    if expert_network.get("status") != "expert_network_ready_local_with_human_review_gates":
        failures.append("expert network should be ready with human review gates")
    if expert_network.get("operation_status") != "expert_network_operational_local_with_human_review_gates":
        failures.append("expert network should include local operation proof")
    if billing_usage.get("status") != "billing_usage_ledger_ready_local_no_charges":
        failures.append("billing usage ledger should be local with no charges")
    if billing_usage.get("executed_usage_event_count", 0) < 1:
        failures.append("billing usage ledger should include executed local usage events")
    if billing_usage.get("external_charge_created") is not False:
        failures.append("billing usage ledger must not create external charges")
    if agent_gateway.get("status") != "agent_api_gateway_ready_local_executor_no_external_effects":
        failures.append("agent API gateway should be ready as local dry run")
    if agent_gateway.get("operation_status") != "agent_api_gateway_executed_local_no_external_effects":
        failures.append("agent API gateway should include local execution proof")
    if agent_gateway.get("executed_tool_count", 0) < 1:
        failures.append("agent API gateway should record executed local tools")
    if launch_operations.get("status") != "launch_operations_ready_for_private_beta_review":
        failures.append("launch operations should be ready for private beta review")
    if launch_operations.get("operation_status") != "launch_operations_operational_local_with_human_approval_gates":
        failures.append("launch operations should include local operation proof")
    if all_stages.get("status") != "all_local_stages_implemented_with_external_gates":
        failures.append("all stage readiness report should mark local stages implemented")
    if all_stages.get("stage_count", 0) < 16:
        failures.append("all stage readiness report should include every local product stage")
    if all_stages.get("operation_status") != "local_product_operations_executed":
        failures.append("all stage readiness should include product operation proof")
    if all_stages.get("local_execution_proof_count", 0) < 8:
        failures.append("all stage readiness should include multiple local execution proofs")
    if not all(stage.get("has_local_execution_proof") for stage in all_stages.get("stages", [])):
        failures.append("every all-stage row should point to local execution proof")
    if product_operations.get("status") != "local_product_operations_executed":
        failures.append(f"product operations report expected executed status, got {product_operations.get('status')!r}")
    if product_operations.get("operation_count", 0) < 8:
        failures.append("product operations report should include executed local operations")
    if product_operations.get("external_effects_created") is not False:
        failures.append("product operations must not create external effects")
    if product_operations.get("claims_opened") is not False:
        failures.append("product operations must not open external claims")
    operation_coverage = product_operations.get("execution_coverage", {})
    for key in (
        "data_intake",
        "research_execution",
        "evidence_reporting",
        "expert_review_routing",
        "team_workspace_activity",
        "billing_metering",
        "agent_tool_execution",
        "launch_control_event",
        "persistence_refresh",
    ):
        if operation_coverage.get(key) is not True:
            failures.append(f"product operations missing execution coverage for {key}")
    if not isinstance(research_runs, list) or not research_runs:
        failures.append("research execution runs should include at least one completed local run")
    elif research_runs[-1].get("status") != "research_execution_completed_local":
        failures.append("latest research execution run should be completed locally")
    if not isinstance(expert_work_orders, list) or not expert_work_orders:
        failures.append("expert review work orders should be generated")
    if not isinstance(team_activity, list) or not team_activity:
        failures.append("team workspace activity should be recorded")
    if not isinstance(launch_events, list) or not launch_events:
        failures.append("launch operation events should be recorded")
    elif any(row.get("public_launch_allowed") is not False for row in launch_events):
        failures.append("launch operation events must keep public launch disabled")
    store_path = ROOT / "system_review_graph" / "customer_workflow.sqlite"
    if store_path.exists():
        with sqlite3.connect(store_path) as conn:
            tables = {
                row[0]
                for row in conn.execute("select name from sqlite_master where type='table'").fetchall()
            }
        for table in (
            "source_packets",
            "evidence_items",
            "official_sources",
            "claims",
            "blockers",
            "review_runs",
            "review_requests",
            "report_exports",
            "users",
            "organizations",
            "memberships",
            "gate_decisions",
            "audit_events",
        ):
            if table not in tables:
                failures.append(f"customer workflow store missing table {table}")
    policy_store_path = ROOT / "system_review_graph" / "policy_intelligence.sqlite"
    if policy_store_path.exists():
        with sqlite3.connect(policy_store_path) as conn:
            policy_tables = {
                row[0]
                for row in conn.execute("select name from sqlite_master where type='table'").fetchall()
            }
        for table in (
            "monitored_sources",
            "source_snapshots",
            "source_change_classifications",
            "packet_source_impacts",
            "stale_source_blockers",
        ):
            if table not in policy_tables:
                failures.append(f"policy intelligence store missing table {table}")
    failures.extend(_validate_blockers(ROOT / "system_review_graph" / "blockers.jsonl"))
    failures.extend(_validate_blocker_rows(external.get("blockers", []), "external_gate_report.blockers"))

    if failures:
        print("Product check: FAIL")
        for failure in failures:
            print(failure)
        return 1

    print("Product check: PASS")
    print(f"status={report['status']}")
    print(f"blocker_count={report['blocker_count']}")
    print(f"external_blocker_count={external['blocker_count']}")
    print(f"continuation_lanes={continuation['lane_count']}")
    print(f"startup_status={continuation['status']}")
    print(f"vc_pitch_status={vc_pitch['status']}")
    print(f"board_go_live_status={board['status']}")
    print(f"operator_workflow_status={workflow['status']}")
    print(f"operator_work_queue_count={workflow['work_queue_count']}")
    print(f"customer_workflow_status={customer['status']}")
    print(f"customer_packet_count={customer['packet_count']}")
    print(f"customer_blocker_count={customer['blocker_count']}")
    print(f"customer_blocker_groups={len(customer['blocker_groups'])}")
    print(f"evidence_ledger_status={evidence_ledger['status']}")
    print(f"runtime_status={runtime['status']}")
    print(f"public_surface_status={runtime['public_product_surface']['status']}")
    print(f"runtime_users={len(runtime['users'])}")
    print(f"public_trade_manifest={public_trade['status']}")
    print(f"exporter_mode_manifest={exporter_mode['status']}")
    print(f"policy_monitor={policy_monitor['status']}")
    print(f"completion_platform={completion['status']}")
    print(f"opportunity_scanner={opportunity_scanner['status']}")
    print(f"country_coverage={country_coverage['status']}")
    print(f"transport_readiness={transport_readiness['status']}")
    print(f"billing_controls={billing_controls['status']}")
    print(f"agent_api={agent_api['status']}")
    print(f"traffic_pages={len(traffic_pages['pages'])}")
    print(f"all_stages={all_stages['status']}")
    print(f"research_execution={research_execution['status']}")
    print(f"team_workspace={team_workspace['status']}")
    print(f"expert_network={expert_network['status']}")
    print(f"billing_usage={billing_usage['status']}")
    print(f"agent_gateway={agent_gateway['status']}")
    print(f"launch_operations={launch_operations['status']}")
    print(f"product_operations={product_operations['status']}")
    print(f"product_operation_count={product_operations['operation_count']}")
    print(f"review_requests={len(review_requests)}")
    print(f"audit_events={len(audit_events['events'])}")
    print(f"deployment_status={deployment['status']}")
    print("customer_store=ready")
    print("unsafe_gates=closed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
