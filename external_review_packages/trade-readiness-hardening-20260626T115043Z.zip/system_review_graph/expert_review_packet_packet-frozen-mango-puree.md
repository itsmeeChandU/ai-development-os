# Expert Review Packet

Packet: Frozen mango puree starter checklist
Product: Frozen mango puree
Trade direction: import
Origin: India
Destination: Canada
Responsibility path: Responsibility path unknown

## Review Scope

This packet requests scoped human/expert review. AI simulation and source refresh records do not open external-world gates.

## Evidence Items

- evidence-packet-frozen-mango-puree-starter-intake: customer_uploaded_reference | blocked_reference_only | Starter context identifies missing evidence and questions only.

## Grouped Blockers

- Source Freshness: Attach evidence and record freshness/rights metadata.
- Compliance Review: Run restricted-party screening and attach the dated search record.
- Source Rights / Contract: Attach source-rights or commercial terms before external use.
- Buyer Validation: Collect buyer/operator validation before demand or PMF claims.

## Official References

- CBSA Assessment and Revenue Management (CARM): https://www.cbsa-asfc.gc.ca/services/carm-gcra/menu-eng.html (Reference source only; does not prove CARM registration, accounting setup, duty payment readiness, or customs advice.)
- CBSA Import Commercial Goods Into Canada: https://www.cbsa-asfc.gc.ca/import/menu-eng.html (Reference source only; does not replace CBSA, broker, customs, or legal review.)
- CBSA Customs Tariff 2026: https://www.cbsa-asfc.gc.ca/trade-commerce/tariff-tarif/2026/menu-eng.html (Reference source only; classification and tariff treatment require qualified review.)
- CFIA Automated Import Reference System (AIRS): https://inspection.canada.ca/en/importing-food-plants-animals/airs (Reference source only; product-specific food import compliance requires qualified review and source verification.)
- Global Affairs Canada Import Controls and Import Permits: https://www.international.gc.ca/controls-controles/about-a_propos/impor/permits-licences.aspx?lang=eng (Reference source only; does not prove whether a specific product requires an import permit.)
- Justice Laws Import Control List: https://laws-lois.justice.gc.ca/eng/regulations/c.r.c.%2C_c._604/index.html (Reference source only; legal interpretation and product applicability require qualified review.)
- Global Affairs Canada Consolidated Canadian Autonomous Sanctions List: https://www.international.gc.ca/world-monde/international_relations-relations_internationales/sanctions/consolidated-consolide.aspx?lang=eng (Reference source only; screening results require dated search records and reviewer signoff.)
- ISED Trade Data Online: https://ised-isde.canada.ca/site/trade-data-online/en/overview (Reference source only; does not prove market size, buyer demand, or revenue.)

## Questions For Reviewer

- Who is the Canadian importer of record for this shipment?
- Which Incoterms or delivery responsibility applies?
- What HS/tariff classification should a qualified reviewer use for the product?
- Does the product need CFIA/AIRS, import permit, controlled goods, sanctions, or restricted-party review?
- Which product specs, invoice/proforma, packing list, certificate, proof-of-origin, and contract documents are still missing?
- Can the Canadian buyer or broker confirm the next valid evidence to collect?
- Responsibility path: Responsibility path unknown.

## Reviewer Response Template

- Reviewer name:
- Qualification / organization:
- Scope reviewed:
- Claims supported:
- Claims rejected or still blocked:
- Additional evidence required:
- Date:
